use mediaDB;

insert into user (userName, userPassword, userAge) values 
("user1", "password", 18);

select * from user;
select * from watchedlist;