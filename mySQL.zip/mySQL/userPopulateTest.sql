use myTestDB;
INSERT INTO user
VALUES (0002, "user2", "example@exmple.com", "password123", 18);

select * from user;